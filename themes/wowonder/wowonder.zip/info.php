<?php
$themeName = 'Fuse';

$themeFolder = 'wowonder';

$themeAuthor = 'Fuse Social';

$themeAuthorUrl = 'mailto:developers@megaloglobal.com';

$themeVirsion = '2.2';

$themeImg = $themeFolder . '/themeLogo.png';
?>